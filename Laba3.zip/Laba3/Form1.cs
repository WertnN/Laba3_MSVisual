﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                if ((textBox1.Text.Length == 0) || (textBox2.Text.Length == 0) || (textBox3.Text.Length == 0) || (textBox4.Text.Length == 0) || (textBox5.Text.Length == 0))
                {
                    MessageBox.Show("Строки для ввода не заполнены!\nЗапоните все строки векторов и повторите попытку.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                        Vector a =  new Vector(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox3.Text), Convert.ToInt32(textBox2.Text));
                        Vector b = new Vector(Convert.ToInt32(textBox6.Text), Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox5.Text));

                        //Сложение векторов
                        Vector c = a + b;
                        //Скалярное произведение векторов
                        //Vector sc = ;
                        //Умножение векторов
                        Vector ymnoz = a * b;
                        //Равество векторов
                        bool rav = a == b;
                        //Неравенство векторов
                        bool nerav = a != b;

                        label1.Text = Convert.ToString(Convert.ToInt32(c.x)) + ", "+ Convert.ToString(Convert.ToInt32(c.y)) + ", "+ Convert.ToString(Convert.ToInt32(c.z));
                        label2.Text = Convert.ToString(Convert.ToInt32(ymnoz.x + ymnoz.y + ymnoz.z));
                        label3.Text = Convert.ToString(Convert.ToInt32(ymnoz.x)) + ", " + Convert.ToString(Convert.ToInt32(ymnoz.y)) + ", " + Convert.ToString(Convert.ToInt32(ymnoz.z));
                        label4.Text = Convert.ToString(rav);
                        label5.Text = Convert.ToString(nerav);
                }
            }
            catch
            {
                MessageBox.Show("Не верный ввод!\nПроверьте все строки векторов и повторите попытку.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        


        class Vector
        {
            public int x { get; set; }
            public int y { get; set; }
            public int z { get; set;}

            public Vector(int x, int y, int z)
            {   
                    this.x = x;
                    this.y = y;
                    this.z = z;    
            }
            public static Vector operator +(Vector a, Vector b)
            {
                return new Vector(a.x + b.x, a.y + b.y, a.z + b.z);
            }

            public static Vector operator *(Vector a, Vector b)
            {
                return new Vector(a.x * b.x, a.y * b.y, a.z * b.z);
            }

            public static bool operator ==(Vector a, Vector b)
            {
                return a.x == b.x && a.y == b.y && a.z == b.z;
            }
            public static bool operator !=(Vector a, Vector b)
            {
                return a.x != b.x && a.y != b.y && a.z != b.z;
            }
        }

        private void TextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && e.KeyChar != 45)
                e.Handled = !Char.IsDigit(e.KeyChar);
        }

        private void TextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && e.KeyChar != 45)
                e.Handled = !Char.IsDigit(e.KeyChar);
        }

        private void TextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && e.KeyChar != 45)
                e.Handled = !Char.IsDigit(e.KeyChar);
        }

        private void TextBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && e.KeyChar != 45)
                e.Handled = !Char.IsDigit(e.KeyChar);
        }

        private void TextBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && e.KeyChar != 45)
                e.Handled = !Char.IsDigit(e.KeyChar);
        }

        private void TextBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && e.KeyChar != 45)
                e.Handled = !Char.IsDigit(e.KeyChar);
        }
    }
}
